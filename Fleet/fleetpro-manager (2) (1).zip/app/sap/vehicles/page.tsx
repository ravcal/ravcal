import { SAPVehicleSync } from "@/components/sap-vehicle-sync"

export default function SAPVehicleSyncPage() {
  return <SAPVehicleSync />
}
