import { SAPIntegrationDashboard } from "@/components/sap-integration-dashboard"

export default function SAPIntegrationPage() {
  return <SAPIntegrationDashboard />
}
